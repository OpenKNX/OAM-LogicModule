﻿### **Nächste Zeile auswerten**

<!-- DOCCONTENT
Wird die Checkbox angeklickt, wird die Zeile mit dem Wert ausgewertet, sonst nicht.
-->

