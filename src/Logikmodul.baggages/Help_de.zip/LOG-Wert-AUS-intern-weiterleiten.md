﻿### **Wert AUS intern weiterleiten**

Wird dieses Auswahlfeld gewählt, wird ein für diesen Ausgang ermitteltes AUS-Signal an alle internen Eingänge weitergeleitet, die mit diesem Ausgang verbunden sind.


