﻿### **Eingang ist EIN wenn Wert gleich**

<!-- DOCCONTENT
Hier wird ein zu vergleichender Wert angegeben.
-->

