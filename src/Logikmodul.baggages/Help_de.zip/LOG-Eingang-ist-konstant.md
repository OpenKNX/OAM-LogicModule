﻿### **Eingang ist konstant**

<!-- DOCCONTENT
Der Eingang wird mit diesem konstanten Wert vorbelegt (z.B. um in Formeln weiter verrechnet zu werden).
-->


