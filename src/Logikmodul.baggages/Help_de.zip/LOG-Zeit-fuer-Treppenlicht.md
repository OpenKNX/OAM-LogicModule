﻿### **Zeit für Treppenlicht**

Hier gibt man die Zeit an, die das Treppenlicht eingeschaltet bleiben soll.

