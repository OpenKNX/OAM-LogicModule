﻿### **oder wenn Wert gleich**

<!-- DOCCONTENT
Hier wird ein weiterer Wert zum Vergleich angegeben.
-->

