﻿### **Wert für AUS ermitteln als**

<!-- DOCCONTENT 
Der Wert des Ausgangs wird ermittelt durch die Berechnung der eingestellten Funktion.
-->

