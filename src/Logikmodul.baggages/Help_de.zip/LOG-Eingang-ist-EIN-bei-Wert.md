﻿### **Eingang ist EIN bei Wert**

<!-- DOCCONTENT
Hier wird ein Wert der Werteliste angegeben.
-->

