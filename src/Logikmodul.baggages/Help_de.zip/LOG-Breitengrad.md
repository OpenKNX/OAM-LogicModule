﻿### **Breitengrad**

In dem Feld wird der Breitengrad des Standortes eingegeben.

